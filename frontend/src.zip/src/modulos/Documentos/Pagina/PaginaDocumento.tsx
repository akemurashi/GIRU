import {
  useEffect,
  useState,
  useRef,
  useMemo,
  type ComponentProps,
} from "react";

import { useSearchParams } from "react-router-dom";
import { useQueries } from "@tanstack/react-query";

import SidebarLayout from "../../Compartido/SidebarLayout";
import { SearchBox } from "../../Compartido/Busqueda";

import {
  FilterSidebar,
  type Filtros,
} from "../Componentes/FilterSidebar";

import { DocumentList } from "../Componentes/DocumentList";

import {
  useSearch,
  useAutocomplete,
  useDocumentById,
  fetchDocumentById,
  mapFrontendFiltersToAPI,
  type SearchRequest,
  type SearchResultItem,
  type DocumentoDetalle,
  type LexicalSuggestionItem,
} from "../../../services/searchService";

// =====================================================
// CONFIGURACIÓN DE PAGINACIÓN
// =====================================================

const DOCUMENTOS_POR_PAGINA = 15;

// =====================================================
// TIPO DE DOCUMENTO
// =====================================================

type Documento = ComponentProps<
  typeof DocumentList
>["documentos"][number];

// =====================================================
// SCROLL
// =====================================================

function useScrollDirection(
  scrollContainerRef: React.RefObject<HTMLDivElement | null>
) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const container = scrollContainerRef.current;

    if (!container) return;

    let previousScrollTop = container.scrollTop;

    const handleScroll = () => {
      const currentScrollTop = container.scrollTop;

      if (currentScrollTop <= 0) {
        setIsVisible(true);
      } else if (currentScrollTop > previousScrollTop) {
        setIsVisible(false);
      } else if (currentScrollTop < previousScrollTop) {
        setIsVisible(true);
      }

      previousScrollTop = currentScrollTop;
    };

    container.addEventListener("scroll", handleScroll, {
      passive: true,
    });

    return () => {
      container.removeEventListener("scroll", handleScroll);
    };
  }, [scrollContainerRef]);

  return isVisible;
}

// =====================================================
// FORMATEAR FECHA UNIFICADA
// =====================================================

const formatearFecha = (fechaStr?: string | null): string => {
  if (!fechaStr) return "Sin fecha";
  try {
    return new Date(fechaStr).toLocaleDateString("es-ES", {
      year: "numeric",
      month: "long",
    });
  } catch {
    return "Sin fecha";
  }
};

// =====================================================
// TRANSFORMAR RESULTADOS DE BÚSQUEDA
// =====================================================

const transformSearchResultToDocumento = (
  searchResult: SearchResultItem
): Documento => {
  return {
    id: searchResult.documentid,
    titulo: searchResult.titulo,
    tipo:
      searchResult.tipodocumento ||
      searchResult.nommetadato ||
      "Documento",
    estado: searchResult.estadovigencia || "Vigente",
    fecha: formatearFecha(searchResult.creacion),
    organismo: searchResult.nommetadato || "Universidad",
    descripcion: searchResult.excerpt || "",
    archivo: `/Pdf/documento_${searchResult.documentid}.pdf`,
  };
};

const transformarDetalleADocumento = (
  detalle: DocumentoDetalle,
  fallbackId: string
): Documento => {
  const id = detalle.iddocumento || fallbackId;

  return {
    id,
    titulo: detalle.titulo || "Documento sin título",
    tipo:
      detalle.tipodocumento ||
      detalle.tipodecision ||
      detalle.nommetadato ||
      "Documento",
    estado:
      detalle.estadovigencia ||
      (detalle.isactive === false ? "No vigente" : "Vigente"),
    fecha: formatearFecha(detalle.creacion),
    organismo: detalle.nommetadato || "Universidad",
    descripcion: detalle.descripcion || "",
    archivo:
      detalle.urlarchivooriginals3 ||
      `/Pdf/documento_${id}.pdf`,
  };
};

// =====================================================
// GENERAR NÚMEROS DE PÁGINA
// =====================================================

type ElementoPaginacion = number | "...";

const generarNumerosPagina = (
  paginaActual: number,
  totalPaginas: number
): ElementoPaginacion[] => {
  if (totalPaginas <= 7) {
    return Array.from(
      { length: totalPaginas },
      (_, indice) => indice + 1
    );
  }

  if (paginaActual <= 4) {
    return [1, 2, 3, 4, 5, "...", totalPaginas];
  }

  if (paginaActual >= totalPaginas - 3) {
    return [
      1,
      "...",
      totalPaginas - 4,
      totalPaginas - 3,
      totalPaginas - 2,
      totalPaginas - 1,
      totalPaginas,
    ];
  }

  return [
    1,
    "...",
    paginaActual - 1,
    paginaActual,
    paginaActual + 1,
    "...",
    totalPaginas,
  ];
};

// =====================================================
// PÁGINA
// =====================================================

export default function PaginaDocumentos() {
  const [searchParams, setSearchParams] = useSearchParams();

  const tipoUrl = searchParams.get("tipo") || "Todos";
  const queryUrl = searchParams.get("query") || "";
  const documentoSeleccionadoId = searchParams.get("docId");

  // ===================================================
  // BÚSQUEDA
  // ===================================================

  const [searchQuery, setSearchQuery] = useState(queryUrl);

  const consultaConfirmada = queryUrl.trim();
  const esBusquedaLexica = consultaConfirmada.startsWith("#");
  const terminoLimpio = consultaConfirmada.replace(/^#+/, "").trim();

  // ===================================================
  // PAGINACIÓN
  // ===================================================

  const [paginaActual, setPaginaActual] = useState(1);

  // ===================================================
  // FILTROS APLICADOS
  // ===================================================

  const [filtros, setFiltros] = useState<Filtros>({
    tipoDocumento: tipoUrl,
    estado: "Todos",
    area: [],
    sede: [],
    departamento: [],
    carrera: [],
    año: [],
  });

  // ===================================================
  // FILTROS PENDIENTES - MÓVIL
  // ===================================================

  const [filtrosPendientes, setFiltrosPendientes] =
    useState<Filtros>({
      tipoDocumento: tipoUrl,
      estado: "Todos",
      area: [],
      sede: [],
      departamento: [],
      carrera: [],
      año: [],
    });

  // ===================================================
  // 1. BÚSQUEDA GENERAL (Cuando NO es léxica)
  // ===================================================

  const searchRequest: SearchRequest = {
    query: terminoLimpio,
    filters: mapFrontendFiltersToAPI(filtros),
    page: paginaActual,
    page_size: DOCUMENTOS_POR_PAGINA,
  };

  const busquedaGeneralHabilitada = !documentoSeleccionadoId && !esBusquedaLexica;

  const {
    data: searchResults,
    isLoading: isLoadingBusqueda,
    error: errorBusqueda,
    refetch: refetchBusqueda,
  } = useSearch(searchRequest, busquedaGeneralHabilitada);

  // ===================================================
  // 2. BÚSQUEDA PARCIAL LÉXICA
  // ===================================================

  const busquedaLexicaHabilitada =
    !documentoSeleccionadoId &&
    esBusquedaLexica &&
    terminoLimpio.length >= 2;

  const {
    data: lexicalResults,
    isFetching: isLoadingLexical,
    isError: errorLexical,
    refetch: refetchLexical,
  } = useAutocomplete(
    `#${terminoLimpio}`,
    8,
    busquedaLexicaHabilitada
  );

  // Extraer IDs únicos encontrados por la búsqueda léxica
  const uniqueDocIds = useMemo(() => {
    if (!lexicalResults?.suggestions) return [];
    const ids = new Set<string>();
    for (const item of lexicalResults.suggestions) {
      if (item.documentid) {
        ids.add(String(item.documentid));
      }
    }
    return Array.from(ids);
  }, [lexicalResults]);

  // Cargar el documento completo para cada ID encontrado (idéntico a la card normal)
  const lexicalDocDetails = useQueries({
    queries: uniqueDocIds.map((id) => ({
      queryKey: ["document-detail", id],
      queryFn: ({ signal }: { signal: AbortSignal }) => fetchDocumentById(id, signal),
      enabled: Boolean(id) && esBusquedaLexica,
      staleTime: 1000 * 60 * 5,
    })),
  });

  const isLoadingLexicalDetails = lexicalDocDetails.some((q) => q.isLoading);

  // ===================================================
  // 3. DETALLE DE DOCUMENTO SELECCIONADO
  // ===================================================

  const {
    data: detalleDocumento,
    isLoading: isLoadingDetalle,
    error: errorDetalle,
    refetch: refetchDetalle,
  } = useDocumentById(documentoSeleccionadoId);

  // ===================================================
  // ESTADOS DE CARGA Y ERROR
  // ===================================================

  const isLoading = documentoSeleccionadoId
    ? isLoadingDetalle
    : esBusquedaLexica
      ? isLoadingLexical || isLoadingLexicalDetails
      : isLoadingBusqueda;

  const error = documentoSeleccionadoId
    ? errorDetalle
    : esBusquedaLexica
      ? errorLexical ? new Error("Error en la búsqueda parcial léxica") : null
      : errorBusqueda;

  const refetch = () => {
    if (documentoSeleccionadoId) {
      refetchDetalle();
    } else if (esBusquedaLexica) {
      refetchLexical();
    } else {
      refetchBusqueda();
    }
  };

  // ===================================================
  // TRANSFORMAR RESULTADOS (Cards idénticas en ambas búsquedas)
  // ===================================================

  const documentosActivos = useMemo<Documento[]>(() => {
    // Caso 1: Detalle por docId específico
    if (documentoSeleccionadoId) {
      if (!detalleDocumento) return [];

      return [
        transformarDetalleADocumento(
          detalleDocumento,
          documentoSeleccionadoId
        ),
      ];
    }

    // Caso 2: Coincidencias de búsqueda léxica (formateadas idénticas a las normales)
    if (esBusquedaLexica) {
      const docsCompletos: Documento[] = [];

      for (let i = 0; i < uniqueDocIds.length; i++) {
        const id = uniqueDocIds[i];
        const detailQuery = lexicalDocDetails[i];

        if (detailQuery?.data) {
          docsCompletos.push(transformarDetalleADocumento(detailQuery.data, id));
        } else {
          // Si el detalle aún está resolviéndose, mostrar la información disponible
          const item = lexicalResults?.suggestions.find((s) => String(s.documentid) === id);
          if (item) {
            docsCompletos.push({
              id,
              titulo: item.titulo || "Documento sin título",
              tipo: item.nommetadato || "Documento",
              estado: "Vigente",
              fecha: "Sin fecha",
              organismo: item.nommetadato || "Universidad",
              descripcion: "",
              archivo: `/Pdf/documento_${id}.pdf`,
            });
          }
        }
      }

      const inicio = (paginaActual - 1) * DOCUMENTOS_POR_PAGINA;
      return docsCompletos.slice(inicio, inicio + DOCUMENTOS_POR_PAGINA);
    }

    // Caso 3: Búsqueda normal sin '#'
    if (!searchResults?.results) return [];

    return searchResults.results.map(
      (item: SearchResultItem) =>
        transformSearchResultToDocumento(item)
    );
  }, [
    documentoSeleccionadoId,
    detalleDocumento,
    esBusquedaLexica,
    uniqueDocIds,
    lexicalDocDetails,
    lexicalResults,
    searchResults,
    paginaActual,
  ]);

  // ===================================================
  // TOTAL DE DOCUMENTOS Y PÁGINAS
  // ===================================================

  const totalDocumentos = documentoSeleccionadoId
    ? detalleDocumento
      ? 1
      : 0
    : esBusquedaLexica
      ? uniqueDocIds.length
      : searchResults?.total ?? 0;

  const totalPaginas = Math.max(
    1,
    Math.ceil(totalDocumentos / DOCUMENTOS_POR_PAGINA)
  );

  const hayPaginaAnterior = paginaActual > 1;
  const hayPaginaSiguiente = paginaActual < totalPaginas;

  const primerDocumento =
    totalDocumentos > 0
      ? (paginaActual - 1) * DOCUMENTOS_POR_PAGINA + 1
      : 0;

  const ultimoDocumento = Math.min(
    paginaActual * DOCUMENTOS_POR_PAGINA,
    totalDocumentos
  );

  const paginasVisibles = useMemo(
    () => generarNumerosPagina(paginaActual, totalPaginas),
    [paginaActual, totalPaginas]
  );

  // ===================================================
  // PANEL MÓVIL
  // ===================================================

  const [mostrarFiltros, setMostrarFiltros] = useState(false);

  // ===================================================
  // SCROLL DE DOCUMENTOS
  // ===================================================

  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const headerVisible = useScrollDirection(scrollContainerRef);

  const volverAlInicio = () => {
    scrollContainerRef.current?.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  // ===================================================
  // EJECUTAR BÚSQUEDA AL PRESIONAR ENTER
  // ===================================================

  const handleSubmitSearch = (query: string) => {
    const consulta = query.trim();

    setSearchQuery(consulta);
    setPaginaActual(1);

    const params = new URLSearchParams(searchParams);

    if (consulta) {
      params.set("query", consulta);
    } else {
      params.delete("query");
    }

    params.delete("docId");

    setSearchParams(params);

    requestAnimationFrame(volverAlInicio);
  };

  // ===================================================
  // SELECCIONAR UNA SUGERENCIA DEL DROPDOWN
  // ===================================================

  const handleSelectSuggestion = (
    item: LexicalSuggestionItem
  ) => {
    const consulta = `#${item.suggestion}`;

    setSearchQuery(consulta);
    setPaginaActual(1);

    const params = new URLSearchParams(searchParams);

    params.set("query", consulta);
    params.set("docId", String(item.documentid));

    setSearchParams(params);

    requestAnimationFrame(volverAlInicio);
  };

  // ===================================================
  // CAMBIAR TEXTO DEL BUSCADOR
  // ===================================================

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);

    if (value.trim() === "" && queryUrl !== "") {
      const params = new URLSearchParams(searchParams);
      params.delete("query");
      params.delete("docId");
      setSearchParams(params);
    }
  };

  // ===================================================
  // SINCRONIZAR BÚSQUEDA DESDE LA URL
  // ===================================================

  useEffect(() => {
    setSearchQuery(queryUrl);
    setPaginaActual(1);
  }, [queryUrl]);

  // ===================================================
  // ACTUALIZAR TIPO DESDE LA URL
  // ===================================================

  useEffect(() => {
    setFiltros((actual) => ({
      ...actual,
      tipoDocumento: tipoUrl,
    }));

    setFiltrosPendientes((actual) => ({
      ...actual,
      tipoDocumento: tipoUrl,
    }));

    setPaginaActual(1);
  }, [tipoUrl]);

  // ===================================================
  // REINICIAR PAGINACIÓN AL CAMBIAR FILTROS
  // ===================================================

  const filtrosKey = JSON.stringify(filtros);

  useEffect(() => {
    setPaginaActual(1);
  }, [filtrosKey]);

  // ===================================================
  // LIMPIAR FILTROS APLICADOS
  // ===================================================

  const limpiarFiltros = () => {
    const filtrosVacios: Filtros = {
      tipoDocumento: "Todos",
      estado: "Todos",
      area: [],
      sede: [],
      departamento: [],
      carrera: [],
      año: [],
    };

    setFiltros(filtrosVacios);
    setPaginaActual(1);
  };

  // ===================================================
  // ABRIR FILTROS MÓVILES
  // ===================================================

  const abrirFiltros = () => {
    setFiltrosPendientes({
      ...filtros,
      area: [...filtros.area],
      sede: [...filtros.sede],
      departamento: [...filtros.departamento],
      carrera: [...filtros.carrera],
      año: [...filtros.año],
    });

    setMostrarFiltros(true);
  };

  // ===================================================
  // ACTUALIZAR FILTROS PENDIENTES
  // ===================================================

  const actualizarFiltrosPendientes = (
    nuevosFiltros: Filtros
  ) => {
    setFiltrosPendientes({
      ...nuevosFiltros,
      area: [...nuevosFiltros.area],
      sede: [...nuevosFiltros.sede],
      departamento: [...nuevosFiltros.departamento],
      carrera: [...nuevosFiltros.carrera],
      año: [...nuevosFiltros.año],
    });
  };

  // ===================================================
  // LIMPIAR FILTROS PENDIENTES
  // ===================================================

  const limpiarFiltrosPendientes = () => {
    setFiltrosPendientes({
      tipoDocumento: "Todos",
      estado: "Todos",
      area: [],
      sede: [],
      departamento: [],
      carrera: [],
      año: [],
    });
  };

  // ===================================================
  // APLICAR FILTROS MÓVILES
  // ===================================================

  const aplicarFiltros = () => {
    setFiltros({
      ...filtrosPendientes,
      area: [...filtrosPendientes.area],
      sede: [...filtrosPendientes.sede],
      departamento: [...filtrosPendientes.departamento],
      carrera: [...filtrosPendientes.carrera],
      año: [...filtrosPendientes.año],
    });

    setPaginaActual(1);
    setMostrarFiltros(false);

    requestAnimationFrame(volverAlInicio);
  };

  // ===================================================
  // CAMBIAR DE PÁGINA
  // ===================================================

  const cambiarPagina = (nuevaPagina: number) => {
    if (
      nuevaPagina < 1 ||
      nuevaPagina > totalPaginas
    ) {
      return;
    }

    if (nuevaPagina === paginaActual) {
      return;
    }

    setPaginaActual(nuevaPagina);
    volverAlInicio();
  };

  // ===================================================
  // RENDER
  // ===================================================

  return (
    <SidebarLayout>
      <div className="flex h-dvh flex-col overflow-hidden bg-white">
        <main className="min-h-0 flex-1 overflow-hidden">
          <div className="flex h-full flex-col xl:flex-row">
            {/* SIDEBAR DE FILTROS - PC */}

            <aside className="hidden shrink-0 border-r border-slate-200 xl:block">
              <FilterSidebar
                filtros={filtros}
                onFiltrosChange={setFiltros}
                onLimpiarFiltros={limpiarFiltros}
              />
            </aside>

            {/* CONTENIDO PRINCIPAL */}

            <section className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden">
              {/* HEADER */}

              <header
                className={`
                  shrink-0
                  relative
                  z-30
                  border-b
                  border-slate-200
                  bg-white
                  px-3
                  py-3
                  transition-[max-height,opacity]
                  duration-300
                  md:p-6
                  md:max-h-none
                  md:opacity-100
                  ${
                    headerVisible
                      ? "max-h-55 opacity-100 overflow-visible"
                      : "max-h-0 border-b-0! py-0! opacity-0 overflow-hidden pointer-events-none"
                  }
                `}
              >
                <h1 className="mb-3 text-xl font-bold text-slate-900 md:text-3xl">
                  Buscar documentos
                </h1>

                <SearchBox
                  value={searchQuery}
                  onChange={handleSearchChange}
                  onSubmitSearch={handleSubmitSearch}
                  onSelectSuggestion={handleSelectSuggestion}
                />

                {/* BOTÓN DE FILTROS - MÓVIL */}

                <button
                  type="button"
                  onClick={() => {
                    if (mostrarFiltros) {
                      setMostrarFiltros(false);
                    } else {
                      abrirFiltros();
                    }
                  }}
                  className="
                    mt-3
                    flex
                    w-full
                    items-center
                    justify-center
                    gap-2
                    rounded-lg
                    border
                    border-sidebar
                    bg-sidebar
                    px-4
                    py-2.5
                    text-sm
                    font-semibold
                    text-white
                    shadow-sm
                    transition
                    hover:bg-slate-900
                    md:hidden
                  "
                >
                  <span>
                    {mostrarFiltros
                      ? "Ocultar filtros"
                      : "Mostrar filtros"}
                  </span>

                  <span
                    className={`transition-transform ${
                      mostrarFiltros ? "rotate-180" : ""
                    }`}
                  >
                    ▼
                  </span>
                </button>
              </header>

              {/* FILTROS - TABLET */}

              <div className="hidden min-h-0 shrink-0 border-b border-slate-200 bg-slate-50 md:block xl:hidden">
                <FilterSidebar
                  filtros={filtros}
                  onFiltrosChange={setFiltros}
                  onLimpiarFiltros={limpiarFiltros}
                  scrollable={false}
                />
              </div>

              {/* DOCUMENTOS Y FILTROS MÓVILES */}

              <div
                ref={scrollContainerRef}
                className="
                  min-h-0
                  flex-1
                  overflow-y-auto
                  overflow-x-hidden
                  px-3
                  py-3
                  pb-8
                  md:p-6
                "
              >
                {/* PANEL DE FILTROS MÓVIL */}

                {mostrarFiltros && (
                  <div className="mb-4 h-[65dvh] max-h-[65dvh] min-h-0 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm md:hidden">
                    <FilterSidebar
                      filtros={filtrosPendientes}
                      onFiltrosChange={actualizarFiltrosPendientes}
                      onLimpiarFiltros={limpiarFiltrosPendientes}
                      onAplicarFiltros={aplicarFiltros}
                      scrollable={true}
                    />
                  </div>
                )}

                {isLoading ? (
                  /* ESTADO DE CARGA */

                  <div className="flex items-center justify-center py-12">
                    <div className="text-center">
                      <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-slate-200 border-t-sidebar" />

                      <p className="text-sm text-slate-600">
                        Cargando documentos...
                      </p>
                    </div>
                  </div>
                ) : error ? (
                  /* ERROR */

                  <div className="rounded-lg border border-red-200 bg-red-50 p-6 text-center">
                    <p className="text-sm text-red-800">
                      {error instanceof Error
                        ? error.message
                        : "Error al cargar los documentos. Por favor, intenta nuevamente."}
                    </p>

                    <button
                      type="button"
                      onClick={refetch}
                      className="
                        mt-4
                        rounded-lg
                        bg-red-600
                        px-4
                        py-2
                        text-sm
                        font-semibold
                        text-white
                        hover:bg-red-700
                      "
                    >
                      Reintentar
                    </button>
                  </div>
                ) : documentosActivos.length === 0 ? (
                  /* SIN RESULTADOS */

                  <div className="rounded-lg border border-slate-200 bg-slate-50 p-8 text-center">
                    <p className="font-medium text-slate-800">
                      No se encontraron documentos
                    </p>

                    <p className="mt-1 text-sm text-slate-500">
                      Prueba modificando la búsqueda o los filtros.
                    </p>
                  </div>
                ) : (
                  <>
                    {/* CONTADOR */}

                    <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                      <p className="text-sm text-slate-600">
                        Mostrando{" "}
                        <span className="font-semibold text-slate-900">
                          {primerDocumento}–{ultimoDocumento}
                        </span>{" "}
                        de{" "}
                        <span className="font-semibold text-slate-900">
                          {totalDocumentos}
                        </span>{" "}
                        documentos encontrados
                      </p>

                      <p className="text-xs text-slate-500">
                        {DOCUMENTOS_POR_PAGINA} por página
                      </p>
                    </div>

                    {/* LISTA DE DOCUMENTOS */}

                    <DocumentList
                      documentos={documentosActivos}
                      documentoSeleccionadoId={documentoSeleccionadoId}
                    />

                    {/* CONTROLES DE PAGINACIÓN */}

                    {!documentoSeleccionadoId && (
                      <nav
                        aria-label="Paginación de documentos"
                        className="mt-8 flex flex-wrap items-center justify-center gap-3 border-t border-slate-200 pt-5"
                      >
                        <button
                          type="button"
                          onClick={() =>
                            cambiarPagina(paginaActual - 1)
                          }
                          disabled={!hayPaginaAnterior || isLoading}
                          className="
                            rounded-lg
                            border
                            border-slate-300
                            bg-white
                            px-4
                            py-2
                            text-sm
                            font-medium
                            text-slate-700
                            transition
                            hover:bg-slate-100
                            disabled:cursor-not-allowed
                            disabled:opacity-40
                          "
                        >
                          Anterior
                        </button>

                        <div className="flex flex-wrap items-center justify-center gap-1.5">
                          {paginasVisibles.map((pagina, indice) => {
                            if (pagina === "...") {
                              return (
                                <span
                                  key={`ellipsis-${indice}`}
                                  aria-hidden="true"
                                  className="px-1.5 py-2 text-sm text-slate-500"
                                >
                                  …
                                </span>
                              );
                            }

                            const esPaginaActual =
                              pagina === paginaActual;

                            return (
                              <button
                                key={pagina}
                                type="button"
                                onClick={() => cambiarPagina(pagina)}
                                disabled={isLoading || esPaginaActual}
                                aria-label={`Ir a la página ${pagina}`}
                                aria-current={
                                  esPaginaActual ? "page" : undefined
                                }
                                className={`
                                  flex
                                  h-9
                                  min-w-9
                                  items-center
                                  justify-center
                                  rounded-lg
                                  border
                                  px-2.5
                                  text-sm
                                  font-medium
                                  transition
                                  disabled:cursor-default
                                  ${
                                    esPaginaActual
                                      ? "border-sidebar bg-sidebar text-white"
                                      : "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
                                  }
                                  disabled:opacity-100
                                `}
                              >
                                {pagina}
                              </button>
                            );
                          })}
                        </div>

                        <button
                          type="button"
                          onClick={() =>
                            cambiarPagina(paginaActual + 1)
                          }
                          disabled={!hayPaginaSiguiente || isLoading}
                          className="
                            rounded-lg
                            border
                            border-sidebar
                            bg-sidebar
                            px-4
                            py-2
                            text-sm
                            font-semibold
                            text-white
                            transition
                            hover:opacity-90
                            disabled:cursor-not-allowed
                            disabled:opacity-40
                          "
                        >
                          Siguiente
                        </button>

                        <span className="w-full text-center text-xs text-slate-500">
                          Página {paginaActual} de {totalPaginas}
                        </span>
                      </nav>
                    )}
                  </>
                )}
              </div>
            </section>
          </div>
        </main>
      </div>
    </SidebarLayout>
  );
}